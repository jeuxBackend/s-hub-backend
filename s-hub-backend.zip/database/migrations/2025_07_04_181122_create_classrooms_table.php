<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('classrooms', function (Blueprint $table) {
            $table->id();
            $table->foreignId('institution_id')->constrained()->onDelete('cascade');

            $table->string('name');
            $table->string('code')->nullable();
            
            $table->foreignId('in_charge_id')->nullable()->constrained('users')->onDelete('set null');

            $table->timestamps();

            // Composite uniqueness within an institution
            $table->unique(['institution_id', 'name']);
            $table->unique(['institution_id', 'code']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('classrooms');
    }
};

