<?php

namespace App\Actions\Admin;

use App\Models\Institution;
use App\Models\User;

class GetSchoolsAction
{
    public function handle(array $data = [])
    {
        $query = Institution::with('manager:id,first_name,last_name,sure_name,email')->with('category');

        if (!empty($data['name'])) {
            $query->where('name', 'like', '%' . $data['name'] . '%');
        }
        if (!empty($data['email'])) {
            $query->where('email', 'like', '%' . $data['email'] . '%');
        }
        if (!empty($data['manager_id'])) {
            $query->where('manager_id', $data['manager_id']);
        }
        if (!empty($data['category_id'])) {
            $query->where('category_id', $data['category_id']);
        }

        return $query->get();
    }
}