<?php

namespace App\Http\Resources;

use App\Enums\UserRole;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class UserResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        $role = $this->role ?? UserRole::Parent;

        $common = [
            'id' => $this->id,
            'email' => $this->email,
            'phone_number' => $this->phone_number,
            'emergency_number' => $this->emergency_number,
            'emergency_contact_name' => $this->emergency_contact_name,
            'role' => $role->value,
            'role_label' => $role->name,
            'address' => $this->address,
            'dob' => $this->dob?->toDateString(),
            'longitude' => $this->longitude,
            'latitude' => $this->latitude,
            'country' => $this->country,
            'state' => $this->state,
            'province' => $this->province,
            'city' => $this->city,
            'nationality' => $this->nationality,
            'country_of_birth' => $this->country_of_birth,
            'primary_language' => $this->primary_language,

            'first_name' => $this->first_name,
            'last_name' => $this->last_name,
            'sur_name' => $this->sur_name,
            'gender' => $this->gender?->value,

            'profile_picture' => $this->profile_picture,
            'created_by' => $this->creator?->full_name,
            'notifications_enabled' => (bool) $this->notifications_enabled,
            'allow_alert' => (bool) ($this->allow_alert ?? true),
            'status' => $this->status,
            'fcm_token' => $this->fcm_token,
            'is_approved' => (bool) ($this->password !== null),
        ];

        $roleFields = match ($role) {
            UserRole::Principal => [
                'title' => $this->title,
                'position' => $this->position,
                'staff_number' => $this->staff_number,
                'address' => $this->address,
                'permissions' => $this->permissions ?? [],
                'institution' => $this->whenLoaded('institution', function () {
                        return new InstitutionResource($this->institution);
                    }),
            ],

            UserRole::SchoolAdmin => [
                'staff_number' => $this->staff_number,
                'position' => $this->position,
                'permissions' => $this->permissions ?? [],
                'remote' => $this->remote_teaching,
                'timetable_availability' => $this->when(
                    array_key_exists('timetable_availability', $this->resource->getAttributes()),
                    $this->timetable_availability
                ),
                'institution' => $this->whenLoaded('institution', fn() => new InstitutionResource($this->institution)),
                // 'emergency_number' => $this->emergency_number,
            ],

            UserRole::Teacher => [
                'staff_number' => $this->staff_number,
                'position' => $this->position,
                'permissions' => $this->permissions ?? [],
                'remote' => $this->remote_teaching,
                'timetable_availability' => $this->when(
                    array_key_exists('timetable_availability', $this->resource->getAttributes()),
                    $this->timetable_availability
                ),
                'institution' => $this->whenLoaded('institution', fn() => new InstitutionResource($this->institution)),
                // 'emergency_number' => $this->emergency_number,
            ],

            UserRole::Parent => [
                'guardian_type' => $this->guardian_type?->value,
                'guardian_name' => $this->guardian_name,
                'guardian_relation' => $this->guardian_relation,
                'guardian_phone_number' => $this->guardian_phone_number,
                'alternative_guardian_phone_number' => $this->alternative_guardian_phone_number,
                'institution' => $this->whenLoaded('institution', fn() => new InstitutionResource($this->institution)),
                'family_members' => $this->whenLoaded('familyMembers', function () {
                        return FamilyMemberResource::collection($this->familyMembers);
                    }),
                'children' => $this->whenLoaded('guardianStudents', function () {
                        return $this->guardianStudents->map(function ($student) {
                            $latestInvoice = $student->relationLoaded('studentInvoices')
                            ? $student->studentInvoices->sortByDesc('id')->first()
                            : null;

                            return [
                            'id' => $student->id,
                            'first_name' => $student->first_name,
                            'last_name' => $student->last_name,
                            'sur_name' => $student->sur_name,
                            'profile_picture' => $student->profile_picture,
                            'student_phone_number' => $student->student_phone_number,
                            'gender' => $student->gender->value ?? null,
                            'dob' => $student->dob?->toDateString(),
                            'age' => $student->age,
                            'term' => $student->term->value ?? null,
                            'registration_number' => $student->registration_number,
                            'status' => $student->status,
                            'classroom' => $student->classroom ? [
                                'id' => $student->classroom->id,
                                'name' => $student->classroom->name,
                                'code' => $student->classroom->code,
                            ] : null,
                            'tuition_status' => $latestInvoice?->status,
                            'total_paid' => $student->relationLoaded('studentInvoices') ? $student->studentInvoices->sum('paid_amount') : 0,
                            'total_due' => $latestInvoice?->due_amount ?? 0,
                            ];
                        });
                    }),
            ],

            default => [],
        };

        return array_merge($common, $roleFields);
    }
}
