<?php

namespace App\Http\Requests\User;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use App\Enums\UserRole;

class UpdateUserRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; // You’re using policies for access control
    }

    public function rules(): array
    {
        $ignoredUserId = $this->route('user')?->id ?? $this->user()?->id;

        // An Admin/SubAdmin/Manager caller (self-service /update-profile only
        // — there's no admin route-model-bound equivalent) lives in the
        // `admins` table, not `users`, so its own email/phone must be
        // checked for uniqueness there instead.
        $uniqueTable = $this->user() instanceof \App\Models\Admin ? 'admins' : 'users';

        return [
            'email' => ['nullable', 'email', Rule::unique($uniqueTable)->ignore($ignoredUserId)],
            'phone_number' => ['nullable', 'string', Rule::unique($uniqueTable)->ignore($ignoredUserId)],
            'emergency_number' => ['nullable', 'string', 'max:100'],
            'emergency_contact_name' => ['nullable', 'string', 'max:100'],
            'password' => ['nullable', 'string', 'min:6', 'confirmed'],
            'first_name' => ['nullable', 'string', 'max:100'],
            'guardian_relation' => ['nullable', 'string', 'max:100'],
            'alternative_guardian_phone_number' => ['nullable', 'string', 'max:100'],
            'guardian_name' => ['nullable', 'string', 'max:100'],
            'sur_name' => ['nullable', 'string', 'max:100'],
            'last_name' => ['nullable', 'string', 'max:100'],
            'country' => ['nullable', 'string', 'max:255'],
            'nationality' => ['nullable', 'string', 'max:100'],
            'country_of_birth' => ['nullable', 'string', 'max:100'],
            'primary_language' => ['nullable', 'string', 'max:100'],
            'title' => ['nullable', 'string', 'max:100'],
            'position' => ['nullable', 'string', 'max:100'],
            'staff_number' => ['nullable', 'string', 'max:100'],
            'device_id' => ['nullable', 'string', 'max:255'],
            'fcm_token' => ['nullable', 'string'],
            'allow_alert' => ['nullable', 'boolean'],
            'address' => ['nullable', 'string'],
            'state' => ['nullable', 'string', 'max:100'],
            'province' => ['nullable', 'string', 'max:100'],
            'city' => ['nullable', 'string', 'max:100'],
            'dob' => ['nullable', 'date'],
            'alternative_email' => ['nullable', 'email'],
            'alternative_phone_number' => ['nullable', 'string'],
            'profile_picture' => ['nullable', 'file', 'image', 'max:2048'],
            'permissions' => ['nullable', 'array'], // only for SchoolAdmins
            // 'permissions.*' => ['string'], // optionally validate each permission string
        ];
    }
}
