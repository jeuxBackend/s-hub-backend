<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\DB;
use App\Models\Student;
use App\Models\StudentInvoice;
use App\Actions\StudentInvoice\CreateStudentInvoiceAction;
use App\Actions\StudentInvoice\UpdateStudentInvoiceAction;
use App\Actions\StudentInvoice\DeleteStudentInvoiceAction;
use App\Actions\StudentInvoice\ListStudentInvoicesAction;
use App\Actions\StudentInvoice\GetStudentInvoiceAction;
use App\Actions\StudentInvoice\GenerateInvoiceReceiptPdfAction;
use Throwable;

class StudentInvoiceController extends Controller
{
    public function index(Request $request, ListStudentInvoicesAction $action)
    {
        try {
            $items = $action->handle($request);
            return $this->paginatedResponse(JsonResource::collection($items), 'Retrieved successfully');
        } catch (Throwable $e) {
            return $this->exceptionResponse($e);
        }
    }

    public function show($id, GetStudentInvoiceAction $action)
    {
        try {
            $item = $action->handle($id);
            $this->assertInScope($item);
            return $this->successResponse($item, 'Retrieved successfully');
        } catch (Throwable $e) {
            return $this->exceptionResponse($e);
        }
    }

    public function store(Request $request, CreateStudentInvoiceAction $action)
    {
        try {
            $data = $request->all();

            $belongsToOwnInstitution = Student::where('id', $data['student_id'] ?? null)
                ->where('institution_id', auth()->user()->institution_id)
                ->exists();

            if (!$belongsToOwnInstitution) {
                return $this->errorResponse('Unauthorized access to this student.', 403);
            }

            $item = $action->handle($data);
            return $this->successResponse($item, 'Created successfully');
        } catch (Throwable $e) {
            return $this->exceptionResponse($e);
        }
    }

    public function update(Request $request, StudentInvoice $studentInvoice, UpdateStudentInvoiceAction $action)
    {
        try {
            $this->assertInScope($studentInvoice);
            $item = $action->handle($studentInvoice, $request->all());
            return $this->successResponse($item, 'Updated successfully');
        } catch (Throwable $e) {
            return $this->exceptionResponse($e);
        }
    }

    public function destroy(StudentInvoice $studentInvoice, DeleteStudentInvoiceAction $action)
    {
        try {
            $this->assertInScope($studentInvoice);
            $action->handle($studentInvoice);
            return $this->successResponse(null, 'Deleted successfully');
        } catch (Throwable $e) {
            return $this->exceptionResponse($e);
        }
    }

    public function pay(Request $request, StudentInvoice $studentInvoice)
    {
        $request->validate([
            'paid_amount' => ['required', 'numeric', 'min:0.01'],
            'paid_date' => ['required', 'date'],
            'payment_method' => ['required', 'string', 'max:255'],
            'document' => ['nullable', 'file', 'mimes:pdf,jpg,jpeg,png,doc,docx', 'max:5120'],
        ]);

        try {
            $this->assertInScope($studentInvoice);

            if ($studentInvoice->status === 'paid') {
                return $this->errorResponse('Invoice is already paid.', 400);
            }

            $paidAmount = (float) $request->input('paid_amount');
            $invoiceTotal = (float) $studentInvoice->total_amount;

            if ($paidAmount > $invoiceTotal) {
                return $this->errorResponse('Paid amount cannot exceed invoice total.', 422);
            }

            $paymentMethod = $request->input('payment_method');
            $paymentType = $paymentMethod === 'external' ? 'external' : 'internal';

            if ($paymentType === 'external' && !$request->hasFile('document')) {
                return $this->errorResponse('Payment proof document is required for external payments.', 422);
            }

            return DB::transaction(function () use ($request, $studentInvoice, $paidAmount) {
                $paymentDate = $request->input('paid_date');
                $paymentMethod = $request->input('payment_method');
                $paymentType = $paymentMethod === 'external' ? 'external' : 'internal';
                $invoiceUuid = $studentInvoice->invoice_uuid ?: \Illuminate\Support\Str::uuid()->toString();
                $documentPath = $paymentType === 'external' && $request->hasFile('document')
                    ? $request->file('document')->store('invoice_payment_proofs', 'public')
                    : null;

                $studentInvoice->update([
                    'invoice_uuid' => $invoiceUuid,
                    'paid_amount' => $paidAmount,
                    'due_amount' => $studentInvoice->total_amount - $paidAmount,
                    'status' => $paidAmount === (float) $studentInvoice->total_amount ? 'paid' : 'partial',
                    'payment_date' => $paymentDate,
                    'payment_method' => $paymentMethod,
                    'payment_type' => $paymentType,
                    'document' => $documentPath,
                ]);

                if ($paidAmount < (float) $studentInvoice->total_amount) {
                    $remainingAmount = $studentInvoice->total_amount - $paidAmount;
                    $paidBy = $studentInvoice->paid_by ?: $studentInvoice->student->guardian_id ?? auth()->id();

                    StudentInvoice::create([
                        'student_id' => $studentInvoice->student_id,
                        'paid_by' => $paidBy,
                        'for_month' => $studentInvoice->for_month,
                        'for_year' => $studentInvoice->for_year,
                        'amount' => $remainingAmount,
                        'discount' => 0,
                        'total_amount' => $remainingAmount,
                        'paid_amount' => 0,
                        'due_amount' => $remainingAmount,
                        'status' => 'unpaid',
                        'payment_date' => null,
                        'payment_method' => null,
                        'payment_type' => null,
                        'document' => null,
                        'reference_no' => null,
                        'invoice_uuid' => $invoiceUuid,
                    ]);
                }

                return $this->successResponse($studentInvoice->fresh(), 'Invoice payment recorded successfully.');
            });
        } catch (Throwable $e) {
            return $this->exceptionResponse($e);
        }
    }

    public function downloadReceipt(StudentInvoice $studentInvoice, GenerateInvoiceReceiptPdfAction $action)
    {
        try {
            $this->assertInScope($studentInvoice);
            return $action->handle($studentInvoice);
        } catch (Throwable $e) {
            return $this->exceptionResponse($e);
        }
    }

    /**
     * Abort with 404 if this invoice's student doesn't belong to the
     * authenticated Principal/SchoolAdmin's own institution.
     */
    private function assertInScope(StudentInvoice $invoice): void
    {
        $invoice->loadMissing('student');

        if (!$invoice->student || $invoice->student->institution_id !== auth()->user()->institution_id) {
            abort(404);
        }
    }
}
