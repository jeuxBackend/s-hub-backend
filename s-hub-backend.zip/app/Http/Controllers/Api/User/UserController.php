<?php

namespace App\Http\Controllers\Api\User;

use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use App\Actions\User\UpdateUserAction;
use App\Actions\User\GetUserAction;
use App\Actions\User\ListUsersAction;
use App\Actions\User\DeleteAccountAction;
use App\Actions\User\ToggleAllowAlertAction;
use App\Actions\User\ToggleNotificationAction;
use App\Http\Requests\User\UpdateUserRequest;
use App\Http\Requests\User\FilterUserRequest;
use App\Models\User;
use Illuminate\Http\Resources\Json\ResourceCollection;
use Throwable;
use App\Http\Requests\User\ChangePasswordRequest;
use App\Actions\User\ChangePasswordAction;
use App\Actions\User\UpdateContactAction;
use App\Http\Requests\User\UpdateContactRequest;
use App\Models\SchoolAlert;


class UserController extends Controller
{
    public function index(FilterUserRequest $request, ListUsersAction $listUsers)
    {
        try {
            $users = $listUsers->handle($request->validated(), auth()->user());

            $resource = new ResourceCollection(UserResource::collection($users));
            $resource->resource = $users;

            return $this->paginatedResponse($resource, 'Users fetched successfully');
        } catch (Throwable $e) {
            return $this->exceptionResponse($e);
        }
    }

    public function show(User $user, GetUserAction $getUser)
    {
        try {
            // $this->authorize('view', $user);
            $result = $getUser->handle($user->id);

            return $this->successResponse(
                [
                    'user' => new UserResource($result)
                ],
                'User fetched successfully'
            );
        } catch (Throwable $e) {
            return $this->exceptionResponse($e);
        }
    }

    public function update(UpdateUserRequest $request, User $user, UpdateUserAction $updateUser)
    {
        try {

            $data = $request->validated();
            $updated = $updateUser->handle($user->id, $data, auth()->user());
            return $this->successResponse(
                [
                    'user' => new UserResource($updated),
                ],
                'User updated successfully'
            );
        } catch (Throwable $e) {
            return $this->exceptionResponse($e);
        }
    }

    public function getAuthenticatedUser(\App\Actions\Teacher\GetOngoingClassAction $getOngoingClassAction)
    {
        try {
            $user = auth()->user();

            if (!$user) {
                return $this->errorResponse('User not authenticated', 401);
            }

            if ($user instanceof \App\Models\Admin) {
                $user->load('assignedSchools:id,name,subadmin_id');

                if ($user->role === \App\Enums\AdminRole::SubManager) {
                    $user->load('subManagerSchools:id,name,sub_manager_id');
                }

                return $this->successResponse([
                    'user' => new \App\Http\Resources\AdminResource($user),
                    'role' => $user->role->value,
                    'is_registered' => !is_null($user->password),
                    'unread_notification_count' => \App\Models\NotificationLog::where('admin_id', $user->id)->where('is_read', false)->count(),
                    'ongoing_class' => null,
                ], 'Authenticated user data retrieved successfully');
            }

            // Load relationships based on user role similar to login action
            if (in_array($user->role, [\App\Enums\UserRole::Principal, \App\Enums\UserRole::Teacher, \App\Enums\UserRole::SchoolAdmin, \App\Enums\UserRole::Parent], true)) {
                $user->load(['institution.watermark']);
            }

            if ($user->role === \App\Enums\UserRole::Parent) {
                $user->load(['guardianStudents', 'familyMembers']);
            }

            if (in_array($user->role, [\App\Enums\UserRole::Principal, \App\Enums\UserRole::SchoolAdmin, \App\Enums\UserRole::Teacher, \App\Enums\UserRole::Parent], true) && $user->relationLoaded('institution') && $user->institution) {
                $activeAlertsQuery = SchoolAlert::where('institution_id', $user->institution_id)
                    ->excludingExpiredAbduction();

                if ($user->role === \App\Enums\UserRole::Principal) {
                    $activeAlertsQuery->where('status', '!=', 'resolved');
                } else {
                    $activeAlertsQuery
                        ->where('status', 'active')
                        ->withinActiveCountWindow();
                }

                $user->institution->setAttribute(
                    'active_alerts_count',
                    $activeAlertsQuery->count()
                );
                $user->institution->setAttribute(
                    'active_alerts_created_by',
                    (clone $activeAlertsQuery)->pluck('created_by')->unique()->values()->all()
                );

                if (in_array($user->role, [\App\Enums\UserRole::Teacher, \App\Enums\UserRole::SchoolAdmin], true)) {
                    $potentialAbductionQuery = SchoolAlert::where('institution_id', $user->institution_id)
                        ->where('type', 'abduction')
                        ->where('status', 'potential')
                        ->excludingExpiredAbduction();

                    $user->institution->setAttribute(
                        'potential_abduction_alerts_count',
                        (clone $potentialAbductionQuery)->count()
                    );
                    $user->institution->setAttribute(
                        'potential_abduction_alerts_created_by',
                        (clone $potentialAbductionQuery)->pluck('created_by')->unique()->values()->all()
                    );
                }
            }
            
            // Get unread notification count
            $unreadNotificationCount = \App\Models\NotificationLog::where('user_id', $user->id)
                ->where('is_read', false)
                ->count();

            return $this->successResponse([
                'user' => new UserResource($user),
                'role' => $user->role->value,
                'is_registered' => !is_null($user->password),
                'unread_notification_count' => $unreadNotificationCount,
                'ongoing_class' => $getOngoingClassAction->handle($user),
            ], 'Authenticated user data retrieved successfully');
        } catch (Throwable $e) {
            return $this->exceptionResponse($e);
        }
    }

    public function updateProfile(UpdateUserRequest $request, UpdateUserAction $updateUser)
    {
        try {
            $data = $request->validated();

            if ($request->hasFile('profile_picture')) {
                $data['profile_picture'] = $this->handleUserFileUpload($request, 'profile_picture', 'profile_pictures');
            }

            $authUser = auth()->user();

            if ($authUser instanceof \App\Models\Admin) {
                $updated = $this->updateAdminOwnProfile($authUser, $data);
                return $this->successResponse(
                    ['user' => new \App\Http\Resources\AdminResource($updated)],
                    'Profile updated successfully'
                );
            }

            $updated = $updateUser->handle($authUser->id, $data, $authUser);
            return $this->successResponse(
                [
                    'user' => new UserResource($updated),
                ],
                'Profile updated successfully'
            );
        } catch (Throwable $e) {
            return $this->exceptionResponse($e);
        }
    }

    /**
     * Admin/sub-admin/manager updating their own profile via the shared
     * update-profile endpoint. Only maps the fields UpdateUserRequest
     * actually validates onto the Admin model's own column names.
     */
    private function updateAdminOwnProfile(\App\Models\Admin $admin, array $data): \App\Models\Admin
    {
        $allowed = array_intersect_key($data, array_flip(['first_name', 'last_name', 'email', 'phone_number']));

        // Managers and sub-admins cannot change their own country — only an
        // Admin (via the dedicated managers/sub-admins endpoints) can set
        // it for them. Admin may still set its own here.
        if (!empty($data['country']) && $admin->role === \App\Enums\AdminRole::Admin) {
            if (!preg_match('/^[A-Za-z]{2}$/', $data['country'])) {
                throw \Illuminate\Validation\ValidationException::withMessages([
                    'country' => ['Country must be a 2-letter country code (e.g. US, GB).'],
                ]);
            }
            $allowed['country'] = strtoupper($data['country']);
        }

        if (array_key_exists('sur_name', $data)) {
            $allowed['sure_name'] = $data['sur_name'];
        }

        if (!empty($data['profile_picture'])) {
            if ($oldPicture = $admin->getRawOriginal('profile_image')) {
                \Illuminate\Support\Facades\Storage::disk('public')->delete($oldPicture);
            }

            $allowed['profile_image'] = $data['profile_picture'];
        }

        if (!empty($data['password'])) {
            $allowed['password'] = \Illuminate\Support\Facades\Hash::make($data['password']);
            $allowed['password_changed_at'] = now();
        }

        $admin->update($allowed);

        return $admin;
    }

    public function destroy(User $user, DeleteAccountAction $deleteAccount)
    {
        try {

            $this->authorize('delete', $user);
            $deleteAccount->handle($user, auth()->user());

            return $this->successResponse(null, 'User deleted successfully');
        } catch (Throwable $e) {
            return $this->exceptionResponse($e);
        }
    }

    public function toggleNotification(User $user, ToggleNotificationAction $toggleNotification)
    {
        try {
            $updated = $toggleNotification->handle($user);

            return $this->successResponse(
                ['user' => new UserResource($updated)],
                'Notification status updated'
            );
        } catch (Throwable $e) {
            return $this->exceptionResponse($e);
        }
    }

    public function toggleAllowAlert(ToggleAllowAlertAction $toggleAllowAlert)
    {
        try {
            $updated = $toggleAllowAlert->handle(auth()->user());

            return $this->successResponse(
                ['user' => new UserResource($updated)],
                'Allow alert status updated'
            );
        } catch (Throwable $e) {
            return $this->exceptionResponse($e);
        }
    }

    public function toggleRemote()
    {
        try {
            $user = auth()->user();
            $user->update([
                'remote_teaching' => !$user->remote_teaching,
            ]);
            return $this->successResponse(
                ['user' => new UserResource($user)],
                'Remote teaching status updated'
            );
        } catch (Throwable $e) {
            return $this->exceptionResponse($e);
        }
    }

    public function updateContact(UpdateContactRequest $request, UpdateContactAction $action)
    {
        try {
            $user = auth()->user();

            $updated = $action->handle($request->validated(), $user);

            return $this->successResponse(
                ['user' => new UserResource($updated)],
                'Contact information updated. OTP verification may be required.'
            );
        } catch (Throwable $e) {
            return $this->exceptionResponse($e);
        }
    }

    public function changePassword(ChangePasswordRequest $request, ChangePasswordAction $action)
    {
        try {
            $user = auth()->user();

            $action->handle($request->validated(), $user);

            return $this->successResponse(null, 'Password updated successfully.');
        } catch (Throwable $e) {
            return $this->exceptionResponse($e);
        }
    }

}
