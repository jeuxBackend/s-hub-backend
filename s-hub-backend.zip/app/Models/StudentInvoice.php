<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StudentInvoice extends Model
{
    protected $fillable = [
        'student_id',
        'paid_by',
        'for_month',
        'for_year',
        'amount',
        'discount',
        'total_amount',
        'paid_amount',
        'due_amount',
        'status',
        'payment_date',
        'payment_method',
        'payment_type',
        'document',
        'reference_no',
        'invoice_uuid',
        'stripe_payment_intent_id',
        'stripe_charge_id',
    ];

    public function getDocumentAttribute($value): ?string
    {
        return $value ? asset('storage/' . $value) : null;
    }

    public function student()
    {
        return $this->belongsTo(Student::class);
    }

    public function payer()
    {
        return $this->belongsTo(User::class, 'paid_by');
    }
}
