<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Models\User;
use App\Models\Category;
use App\Models\Admin;

class Institution extends Model
{
    protected $fillable = [
        'manager_id',
        'subadmin_id',
        'sub_manager_id',
        'category_id',
        'status',
        'type',
        'is_blocked',
        'name',
        'slogan',
        'logo',
        'principal_signature',
        'stamp',
        'academic_year',
        'examination_system',
        'physical_address',
        'region',
        'country',
        'email',
        'alternate_email',
        'phone_number',
        'alternate_phone',
        'telephone',
        'email_verified',
        'phone_verified',
        'alert_feature_enabled',
        'allowed_alert_types',
        'mock_exam_classroom_ids',
        'subjects',
        'latitude',
        'longitude',
        'timezone',
    ];

    protected $casts = [
        'email_verified' => 'boolean',
        'phone_verified' => 'boolean',
        'is_blocked' => 'boolean',
        'alert_feature_enabled' => 'boolean',
        'allowed_alert_types' => 'array',
        'mock_exam_classroom_ids' => 'array',
        'subjects' => 'array',
        'type' => 'array',
    ];

    public function getTypeAttribute($value): array
    {
        if (empty($value)) {
            return [];
        }

        if (is_array($value)) {
            return array_values($value);
        }

        $decoded = json_decode($value, true);
        return is_array($decoded) ? array_values($decoded) : [];
    }

    public function getLogoAttribute($value): ?string
    {
        return $value
            ? asset('storage/' . $value)
            : asset('defaults/user.png');
    }

    public function getPrincipalSignatureAttribute($value): ?string
    {
        return $value ? asset('storage/' . $value) : null;
    }

    public function getStampAttribute($value): ?string
    {
        return $value ? asset('storage/' . $value) : null;
    }

    public function principal()
    {
        return $this->hasOne(User::class, 'institution_id')->where('role', \App\Enums\UserRole::Principal->value);
    }

    public function students()
    {
        return $this->hasMany(Student::class, 'institution_id');
    }

    public function teachers()
    {
        return $this->hasMany(User::class, 'institution_id')
            ->whereIn('role', [\App\Enums\UserRole::Teacher->value, \App\Enums\UserRole::SchoolAdmin->value]);
    }

    public function schoolAdmins()
    {
        return $this->hasMany(User::class, 'institution_id')->where('role', \App\Enums\UserRole::SchoolAdmin->value);
    }

    public function watermark()
    {
        return $this->hasOne(SchoolAsset::class, 'institution_id')->where('type', \App\Enums\SchoolAssetType::Watermark->value);
    }

    public function classrooms()
    {
        return $this->hasMany(Classroom::class, 'institution_id');
    }

    public function manager(): BelongsTo
    {
        return $this->belongsTo(Admin::class, 'manager_id');
    }

    public function subManager(): BelongsTo
    {
        return $this->belongsTo(Admin::class, 'sub_manager_id');
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }

    public function timetableConfigs()
    {
        return $this->hasMany(SchoolTimetableConfig::class);
    }

    public function teacherAvailabilities()
    {
        return $this->hasMany(TeacherAvailability::class);
    }

    public function classSubjectRequirements()
    {
        return $this->hasMany(ClassSubjectRequirement::class);
    }
}
